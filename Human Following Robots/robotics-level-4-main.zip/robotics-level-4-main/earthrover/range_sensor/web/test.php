
<html>
<head>        
   <title>Range Sensor</title>
   
   <script src="/earthrover/js/jquery.min.js"></script>
        
   
</head> 
<body style='background-color:lightgrey'>

	<input id='range_button' type='submit' onclick=toggle_rangeSensor('range_button'); value='OFF'/><br>
	
	<b id='range' style='float:left;margin-left:25%;color:blue;font-size:300px;'></b>
	<script src='rangesensor.js'></script>
		
</body>
</html>
