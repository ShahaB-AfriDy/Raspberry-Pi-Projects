All files run on computer. 
For video streaming/ultrasonic sensor test, start the server program first and then start the corresponding client program in the "raspberryPi" folder.
