"""utils.py: File containing utility functions"""

server_address = ('10.104.64.231', 45713)
# server_address = ('192.168.0.88', 45713)


