## Bill of Materials

* RC Car: any cheap RC Car
* Arduino: https://www.amazon.com/Arduino-A000066-ARDUINO-UNO-R3/dp/B008GRTSV6/ref=sr_1_3?keywords=arduino+rev3&qid=1580224379&s=electronics&sr=1-3
* RPi: https://www.amazon.com/Raspberry-Pi-MS-004-00000024-Model-Board/dp/B01LPLPBS8/ref=sr_1_3?keywords=Raspberry+Pi+3+Model+B+Board&qid=1580224357&s=electronics&sr=1-3
* Connector wires: https://www.amazon.com/Elegoo-EL-CP-004-Multicolored-Breadboard-arduino/dp/B01EV70C78/ref=sr_1_1?keywords=Elegoo+EL-CP-004+120pcs+Multicolored+Dupont+Wire+40pin+Male+to+Female%2C+40pin+Male+to+Male%2C+40pin+Female+to+Female+Breadboard+J&qid=1580224429&s=electronics&sr=1-1
* RPi Camera: https://www.amazon.com/Raspberry-Pi-Camera-Module-Megapixel/dp/B01ER2SKFS/ref=sr_1_3?keywords=Raspberry+Pi+Camera+Module+V2-8+Megapixel%2C1080p&qid=1580224481&s=electronics&sr=1-3
* Traffic Light: https://www.amazon.com/Mini-Traffic-Light-Arduino-breadboards/dp/B07N7W64BJ/ref=sr_1_6?keywords=mini+traffic+lights&qid=1580224559&s=electronics&sr=1-6
* Ultrasonic Sensor: https://www.amazon.com/HC-SR04-Ultrasonic-Distance-MEGA2560-ElecRight/dp/B07H5D43QH/ref=sr_1_1?keywords=HC-SR04+Ultrasonic+Sensor+Distance+Module+%2810pcs%29+for+Arduino+UNO&qid=1580224615&s=electronics&sr=1-1
* Wifi dongle RPi: https://www.amazon.com/CanaKit-Raspberry-Wireless-Adapter-Dongle/dp/B00GFAN498/ref=sr_1_3?keywords=CanaKit+Raspberry+Pi+WiFi+Wireless+Adapter%2FDongle&qid=1580224672&s=electronics&sr=1-3
