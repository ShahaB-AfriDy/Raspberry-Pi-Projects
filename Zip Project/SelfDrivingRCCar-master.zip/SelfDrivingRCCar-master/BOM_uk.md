## Bill of Materials

* RC Car: any cheap RC Car
* Arduino: https://www.amazon.co.uk/Arduino-A000066-ATMEGA328-Microcontroller-Board/dp/B008GRTSV6/ref=sr_1_4?s=computers&ie=UTF8&qid=1504539068&sr=1-4&keywords=arduino
* RPi: https://www.amazon.co.uk/Raspberry-Pi-Model-Quad-Motherboard/dp/B01CD5VC92/ref=sr_1_4?s=computers&ie=UTF8&qid=1504539053&sr=1-4&keywords=raspberry+pi
* Connector wires: https://www.amazon.co.uk/gp/product/B01EV70C78/ref=oh_aui_detailpage_o04_s00?ie=UTF8&psc=1
* RPi Camera: https://www.amazon.co.uk/Raspberry-Pi-1080p-Camera-Module/dp/B01ER2SKFS/ref=sr_1_1?ie=UTF8&qid=1504539009&sr=8-1&keywords=rpi+camera
* Traffic Light: https://www.amazon.co.uk/gp/product/B012CTHSVK/ref=oh_aui_detailpage_o06_s00?ie=UTF8&psc=1
* Ultrasonic Sensor: https://www.amazon.co.uk/gp/product/B01M0QL1F1/ref=oh_aui_detailpage_o05_s01?ie=UTF8&psc=1
* Wifi dongle RPi: https://www.amazon.co.uk/gp/product/B012CTHSVK/ref=oh_aui_detailpage_o06_s00?ie=UTF8&psc=1
